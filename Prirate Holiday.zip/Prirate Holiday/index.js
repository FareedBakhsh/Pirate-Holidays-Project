function expandCard(card) {
  var cardContent = document.querySelector('#expanded-card');
  var cardClone = card.cloneNode(true);
  cardContent.innerHTML = '';
  cardContent.appendChild(cardClone);
  cardContent.style.display = 'block';
}
