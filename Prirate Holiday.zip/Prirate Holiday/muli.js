function showImage(imageUrl) {
    document.getElementById('mainImage').src = imageUrl;
  }
  